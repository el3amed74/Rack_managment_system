<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Our Clients</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <link rel="icon" type="image/png" href="<?php echo e(asset('images/tap-icon.svg')); ?>">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1200px;
            margin: 40px auto;
            padding: 0 15px;
        }

        .header-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        h2 {
            font-size: 28px;
            margin: 0;
            color: #333;
        }

        .btn-dark {
            background-color: #343a40;
            color: white;
            padding: 7px 15px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: 600;
            font-size: 14px;
            margin-right: 15px;
        }

        .btn-dark:hover {
            background-color: #23272b;
        }

        img.filter-icon {
            width: 30px;
            height: 30px;
            cursor: pointer;
            vertical-align: middle;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }

        .grid a {
            display: block;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .grid a:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .grid img {
            width: 100%;
            height: auto;
            object-fit: contain;
        }

        .header-text {
            text-align: left;
            position: absolute;
            top: 10px;
            left: 40px;
            z-index: 10;
        }

        .welcome-message {
            font-size: 24px;
            font-weight: bold;
            color: #343a40;
            margin: 0;
        }
    </style>
</head>

<body>
    <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->role_id === 'admin'): ?>
            
            <div class="container position-relative bg-white rounded shadow" style="min-height: 120px;">
                <div class="header-text">
                    <p class="welcome-message mb-1">
                        Welcome back, <?php echo e(Auth::user()->name ?? 'User'); ?>

                    </p>
                    <p class="hotel-name">
                        Role: <?php echo e(Auth::user()->role_id ?? 'User'); ?>

                    </p>
                </div>

                <div class="d-flex position-absolute" style="top: 20px; right: 40px; gap: 15px;">
                    <a href="<?php echo e(route('hotels.create')); ?>"
                        class="btn-dark text-white px-4 py-2 rounded hover:bg-gray-700 transition">
                        + Add Hotel
                    </a>
                    <a href="<?php echo e(route('adduser')); ?>" class="btn btn-dark fw-semibold px-4 py-2 rounded">
                        + Add User
                    </a>
                    <a href="<?php echo e(route('logOut')); ?>" class="btn btn-dark fw-semibold px-4 py-2 rounded">
                        logout
                    </a>
                </div>
            </div>
            <div class="container mx-auto px-4 py-6">

                
                <div class="mb-4">
                    <h2 class="text-xl font-bold text-gray-700">Our Clients</h2>
                </div>

                
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    <?php if($hotels->count()): ?>
                        <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('hotels/' . $hotel->id . '/buildings')); ?>"
                                class="block border rounded shadow hover:shadow-md transition">
                                <img src="<?php echo e(asset($hotel->logo)); ?>" alt="<?php echo e($hotel->name); ?>"
                                    class="w-full h-32 object-contain p-2 bg-white" />
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p class="text-gray-500 col-span-full">No hotels found.</p>
                    <?php endif; ?>
                </div>
            </div>
        <?php else: ?>
            <div class="container d-flex justify-content-center align-items-center min-vh-100">
                <h1 class="text-center">Access denied, you have no permission</h1>
            </div>

        <?php endif; ?>
    <?php endif; ?>

</body>

</html>
<?php /**PATH D:\Rack_managment_system\resources\views/index/hotels.blade.php ENDPATH**/ ?>