<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" />
    <title>Add building</title>
</head>

<body>
    <div class="container my-5">
        <div class="card shadow-lg p-4 rounded-4">
            <h2 class="mb-4 text-center">Add New Building</h2>
            <form method="POST" action="<?php echo e(route('storebuilding')); ?>">
                <?php echo csrf_field(); ?> <!-- include this if it's a Laravel form -->
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <div class="mb-3">
                    <label for="rackId" class="form-label">Rack ID</label>
                    <input type="text" name="rackid" id="rackId" class="form-control" placeholder="Enter Rack ID"
                        required>
                </div>

                <div class="mb-3">
                    <label for="brackId" class="form-label">Building Rack ID</label>
                    <input type="text" name="brackid" id="brackId" class="form-control"
                        placeholder="Enter Building Rack ID" required>
                </div>

                <div class="mb-3">
                    <label for="buildingName" class="form-label">Building Name</label>
                    <input type="text" name="buildingName" id="buildingName" class="form-control"
                        placeholder="Enter Building Name" required>
                </div>

                <div class="mb-3">
                    <label for="hotelId" class="form-label">Select Hotel</label>
                    <select name="hotel_id" id="hotelId" class="form-select" required>
                        <option value="">-- Select a Hotel --</option>
                        <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($hotel->id); ?>"><?php echo e($hotel->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>


                <div class="d-grid">
                    <button type="submit" class="btn btn-primary btn-lg rounded-3">Add Building</button>
                </div>
            </form>
        </div>
    </div>

</body>

</html>
<?php /**PATH D:\Rack_managment_system\resources\views/index/addbuilding.blade.php ENDPATH**/ ?>