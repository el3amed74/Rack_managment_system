<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Add new Rack</title>
</head>

<body>
    <div class="container my-5">
        <div class="card p-4 shadow rounded-4">
            <h2 class="text-center mb-4">Add New Rack</h2>
            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <form action="<?php echo e(route('storerack')); ?>" method="POST">
                <?php echo csrf_field(); ?> <!-- Laravel CSRF token -->
                <?php echo method_field('POST'); ?>
                <div class="row">
                    <!-- Product Data Column -->
                    <div class="col-md-6">
                        <h5 class="mb-3">Product Data</h5>

                        <div class="mb-3">
                            <label class="form-label">Building Rack ID</label>
                            <select name="building_r_id" id="building_r_id" class="form-select" required>
                                <option value="">-- Select a Building and Rack --</option>
                                <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($building->building_r_id); ?>">BName :<?php echo e($building->building_name); ?>: RackId <?php echo e($building->building_r_id); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Switch ID</label>
                            <select name="switch_id" id="switch_id" class="form-select" required>
                                <option value="">-- Select a switch --</option>
                                <?php $__currentLoopData = $switches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $switche): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($switche->id); ?>"><?php echo e($switche->serial_number); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product Panel</label>
                            <input type="text" name="product_panal" class="form-control" placeholder="product_panal">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product Serial</label>
                            <input type="text" name="product_serial" class="form-control"
                                placeholder="product_serial">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product MAC</label>
                            <input type="text" name="product_mac" class="form-control" placeholder="product_mac">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product Model</label>
                            <input type="text" name="product_model" class="form-control" placeholder="product_model">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product Port</label>
                            <input type="text" name="product_port" class="form-control" placeholder="product_port">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Device Name</label>
                            <input type="text" name="device_name" class="form-control" placeholder="device_name">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Site Name</label>
                            <input type="text" name="site_name" class="form-control" placeholder="site_name">
                        </div>
                    </div>

                    <!-- Switch Data Column -->
                    

                    <!-- Submit Button -->
                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-primary px-5 py-2">Add Rack</button>
                    </div>
            </form>
        </div>
    </div>

</body>

</html>
<?php /**PATH D:\Rack_managment_system\resources\views/index/addrack.blade.php ENDPATH**/ ?>