<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <title>Rack Info - Split Tables</title>

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />

    <style>
        
        .table-container {
            margin-top: 60px;
        }

        

        .table-sm td,
        .table-sm th {
            padding: 0.3rem;
        }

        .table-responsive {
            max-height: 50vh;
            overflow-y: auto;
            margin-bottom: 40px;
        }

        h2 {
            margin-bottom: 30px;
        }
    </style>
</head>

<body>

    <div class="container table-container">
        

        <?php if($hotel->logo): ?>
                    <div class="logo-container mb-4 ">
                        <img src="<?php echo e(asset($hotel->logo)); ?>" alt="Hotel Logo" class="hotel-logo">
                    </div>
                <?php endif; ?>
        <?php if($rackinfo->count()): ?>
        <!-- Product & Device Info Table -->
        <div class="container table-container">
            
            <h4>Product & Device Info</h4>
            <div class="table-responsive">
                
                <table class="table table-bordered table-striped table-hover table-sm align-middle text-center">
                    <thead>
                        <tr>
                            <th class="th">Building Rack ID</th>
                            <th>Product Panel</th>
                            <th>Product Serial</th>
                            <th>Product MAC</th>
                            <th>Product Model</th>
                            <th>Product Port</th>
                            <th>Device Name</th>
                            <th>Site Name</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rackinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($rack->building_r_id); ?></td>
                                <td><?php echo e($rack->product_panal); ?></td>
                                <td><?php echo e($rack->product_serial); ?></td>
                                <td><?php echo e($rack->product_mac); ?></td>
                                <td><?php echo e($rack->product_model); ?></td>
                                <td><?php echo e($rack->product_port); ?></td>
                                <td><?php echo e($rack->device_name); ?></td>
                                <td><?php echo e($rack->site_name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            

            <!-- Network & Switch Info Table -->
            <h4>Network & Switch Info</h4>
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover table-sm align-middle text-center">
                    <thead>
                        <tr>
                            <th>Switch ID</th>
                            <th>Serial Number</th>
                            <th>MAC Address</th>
                            <th>IP Address</th>
                            <th>Uplink Core 1</th>
                            <th>Uplink Core 2</th>
                            <th>Port Number</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rackinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rack): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($rack->switch_id); ?></td>
                                <td><?php echo e($rack->serial_number); ?></td>
                                <td><?php echo e($rack->mac_add); ?></td>
                                <td><?php echo e($rack->ip_add); ?></td>
                                <td><?php echo e($rack->up_link_core1); ?></td>
                                <td><?php echo e($rack->up_link_core2); ?></td>
                                <td><?php echo e($rack->port_number); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
                <p class="text-gray-500 col-span-full">No Racks found.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html><?php /**PATH D:\Rack_managment_system\resources\views/rackInfo.blade.php ENDPATH**/ ?>