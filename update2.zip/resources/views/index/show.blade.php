<!-- resources/views/hotels/show.blade.php -->
<h1>Hotel Details</h1>
<p>Display hotel information here.</p>
