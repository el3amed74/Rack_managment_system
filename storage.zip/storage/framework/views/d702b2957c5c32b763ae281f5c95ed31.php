<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Create Product</h1>
    <form action="<?php echo e(route('product.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('post'); ?>
        <div>
            <lable>Name</lable>
            <input type="text" name="name" plasholder="Name"/>
        </div>
        <div>
            <lable>Qty</lable>
            <input type="text" name="qty" plasholder="Qty"/>
        </div>
        <div>
            <lable>Price</lable>
            <input type="text" name="price" plasholder="Price"/>
        </div>
        <div>
            <lable>Description</lable>
            <input type="text" name="description" plasholder="Description"/>
        </div>
        <div>
            <input type="submit" value="submit"/>
        </div>
    </form>
</body>
</html><?php /**PATH D:\test-app\resources\views/product/create.blade.php ENDPATH**/ ?>