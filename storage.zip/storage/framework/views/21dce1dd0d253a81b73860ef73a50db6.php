<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <div>
        <h1>Log In</h1>
        <form action="/login" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('post'); ?>
            <input type="text" name="email" placeholder="Email" id="">
            <input type="password" name="password" placeholder="Password" id="">
            <input type="submit" value="LogIn"/>
        </form>
    </div>
</body>
</html><?php /**PATH D:\test-app\resources\views/login.blade.php ENDPATH**/ ?>