<?php

namespace App\Http\Controllers;
use App\Models\User;


use Illuminate\Http\Request;
use App\Http\Controllers;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{

    public function login(Request $request)
    {
        $inputFields = $request->validate([
            'email' => 'required',
            'password' => 'required',
        ]);

        if (!empty($inputFields['email']) && !empty($inputFields['password'])) {
            // $request->session()->regenerate();
            return redirect('index');
        }
        return redirect('/');
    }

}
